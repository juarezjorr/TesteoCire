<?php defined('BASEPATH') or exit('No se permite acceso directo');
require ROOT . FOLDER_PATH . "/app/assets/header.php";
?>

  <!-- Main jumbotron for a primary marketing message or call to action -->
  <div class="container text-center">
    <h1>Error 404</h1>
    <h2>Oops! P&aacute;gina no encontrada</h2>
    <a href="<?php echo $path_inicio ?>">Ir a inicio</a>
  </div>
</body>
</html>