var seccion = '';

$(document).ready(function () {
	console.log('start');
	pos = 4;
	verifica_usuario();
	// busca_sidebar();
});
