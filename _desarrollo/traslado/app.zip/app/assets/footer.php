
    <div class="final"></div>
    <footer>
    <div class="copy"></div>
    <div class="logo"></div>
    </footer>
</body>
</html>