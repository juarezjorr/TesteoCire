<h3>Catálogos</h3>
<ul>
    <li><a href="TAdminDestinos" class="destinos"><i class="fas fa-map-marker-alt"></i>Destinos</a></li>
    <li><a href="TAdminEmpleados" class="empleados"><i class="fas fa-people-arrows"></i>Empleados</a></li>
    <li><a href="TAdminPuestos" class="puestos"><i class="fas fa-user-tag"></i>Puestos</a></li>
    <li><a href="TAdminTarjetas" class="tarjetas"><i class="fas fa-credit-card"></i>Tarjetas</a></li>
    <li><a href="TAdminUnidades" class="unidades"><i class="fas fa-truck"></i>Unidades</a></li>
    <li><a href="TAdminUsuarios" class="usuarios"><i class="fas fa-users"></i>Usuarios</a></li>
</ul>