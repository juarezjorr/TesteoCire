<?php
  	defined('BASEPATH') or exit('No se permite acceso directo'); 
?>

<input type="checkbox" id="btn_menu">
<label for="btn_menu"><i class="fas fa-bars"></i></label>

        <ul class="menu">
            <li class="noshow Schedule" id="0"><a href="Schedule">Programación<br>de salidas</a></li>
            <li class="noshow StartingFlag" id="1"><a href="StartingFlag">Registros<br>de Salidas</a></li>
            <li class="noshow EntryRecords"><a href="EntryRecords">Registros<br>de Entradas</a></li>
            <li class="noshow Dashboard"><a href="TPanel">Panel de control</a></li>
            <li class="noshow TAdmin"><a href="TAdmin">Administración</a></li>
        </ul>

    </div>
</header>