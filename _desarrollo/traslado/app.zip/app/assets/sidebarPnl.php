<h3>Reportes</h3>
<ul>
    <li><a href="TPanel" class="dashboard">Principal</a></li>
    <li><a href="#" >Reporte de salidas</a>
        <ul>
            <li><a href="TPanel_Rep001" class="reporte01">Unidades</a></li>
            <li><a href="TPanel_Rep002" class="reporte02">Plantas</a></li>
        </ul>
    </li>
    <li><a href="TPanel_Rep003" class="reporte03" >Reporte de consumo</a>    </li>
</ul>