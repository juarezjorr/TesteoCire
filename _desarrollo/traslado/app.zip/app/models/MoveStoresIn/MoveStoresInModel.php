<?php
defined('BASEPATH') or exit('No se permite acceso directo');

class MoveStoresInModel extends Model
{

    public function __construct()
    {
      parent::__construct();
    }


// Listado de Tipos de movimiento
    public function listExchange()
    {
        $qry = "SELECT ex1.ext_id, ex1.ext_code, ex1.ext_type, ex1.ext_description, ex1.ext_link,
                    ex2.ext_id as ext_id_a, ex2.ext_code as ext_code_a, ex2.ext_type as ext_type_a, ex2.ext_description as ext_description_a,
                    ex1.ext_elements
                FROM ctt_type_exchange AS ex1
                LEFT JOIN ctt_type_exchange AS ex2 ON ex2.ext_link = ex1.ext_id 
                WHERE ex1.ext_type = 'E';";
        return $this->db->query($qry);
    }


// Listado de Almacecnes
    public function listStores()
    {
        $qry = "  SELECT * FROM ctt_stores WHERE str_status = 1";
        return $this->db->query($qry);
    }


// Listado de proveedores
    public function listSuppliers()
    {
        $qry = "  SELECT * FROM ctt_suppliers WHERE sup_status = 1 AND sut_id IN (3);";
        return $this->db->query($qry);
    }

    
// Listado de Facturas
    public function listInvoice()
    {
        $qry = "SELECT doc_id, doc_name FROM ctt_documents WHERE dot_id = 1;";
        return $this->db->query($qry);
    }

        
// Listado de Monedas
    public function listCoins()
    {
        $qry = "SELECT cin_id, cin_code, cin_name FROM ctt_coins WHERE cin_status = 1;";
        return $this->db->query($qry);
    }

// Listado de Productos
    public function listProducts()
    {
        $qry = "SELECT pd.prd_id, pd.prd_sku, pd.prd_name, (
                    SELECT ifnull(max(convert(substring( ser_sku,8,3), signed integer)),0) + 1 
                    FROM ctt_series WHERE prd_id = pd.prd_id AND ser_behaviour = 'C'
                ) as serNext
                FROM ctt_products AS pd WHERE pd.prd_status = 1 AND pd.prd_level ='P';";
        return $this->db->query($qry);
    }	

}