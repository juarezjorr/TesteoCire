<?php 
/**
* 
*/
class LoginModel extends Model
{
  
  public function __construct()
  {
    parent::__construct();
  }

  public function signIn($empleado)
  {
    $empleado = $this->db->real_escape_string($empleado);

    $sql = "SELECT *  FROM sic_usuarios AS usr 
            INNER JOIN sic_empleados AS emp ON emp.emp_id = usr.emp_id
            INNER JOIN sic_perfiles AS per ON per.prf_id = usr.prf_id 
            WHERE usr.emp_numero =  '{$empleado}'";
            
    return $this->db->query($sql);
  }
}