function avisos_select(dt) {
    
    avisos_listado();

    $('.btn_file').on('click', function () {
        $('#txt_file').trigger('click');
    })
    $('#txt_file').on('change', function () {
        $('#txt_filefake').removeClass('alerta');
        $(this).parent().parent().children('div.nota').html('');
        $('#txt_filefake').val($(this).val());
    })

    $('.textbox').on('focus', function () {
        $(this).removeClass('alerta');
        $(this).parent().parent().children('div.nota').html('');
    })

    $('#formfile').on('submit', function (e) {
        e.preventDefault();
        $('.loader').removeClass('oculto');
        if (avisos_valida() == 1) {
            var f = $(this);
            var formData = new FormData(document.getElementById('formfile'));
            formData.append('dato', 'valor');
            $.ajax({
                url: '../admin/avisos-agrega.php',
                type: 'post',
                dataType: 'html',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function (dt) {
                    if (dt == 1) {
                        avisos_listado();
                        $('.textbox').val('');
                        $('.loader').addClass('oculto');
                    } else {
                        console.log(dt);
                    }
                },
                error: function (xhr, textStatus, error) {
                    show_error(xhr, textStatus, error);
                }
            })
        }else { $('.loader').addClass('oculto');}
    });

}

function avisos_listado() {
    $('.lista').html('');
    $.ajax({
        url: '../admin/avisos-lista.php',
        type: 'post',
        dataType: 'json',
        cache: false,
        success: function (dt) {
console.log(dt);
            $.each(dt, function (v, u) {
                var H = '';
                H += '<div class="elemento" id="' + u.avs_id + '">';
                H += '  <i class="fas fa-download  icono" id="dwnld" title="descargar archivo: \n' + u.avs_filename + '"></i>';
                H += '  <i class="fas fa-paperclip icono" id="edita" title="editar circular"></i>';
                H += '  <i class="fas fa-trash-alt icono" id="delet" title="eliminar circular"></i>';
                H += ' <span>' + u.avs_month + '</span>';
                H += '</div>';

                $('#' + u.avs_level).append(H);

            });

            $('.icono').unbind('click').on('click', function () {
                var obj = $(this);
                var accn = obj.attr('id')
                var id = obj.parent().attr('id')
                switch(accn){
                    case 'dwnld': avisos_descarga(id); break;
                    case 'edita': avisos_edita(id); break;
                    case 'delet': avisos_elimina(id); break;
                    default:
                }
            });

        },
        error: function (xhr, textStatus, error) {
            show_error(xhr, textStatus, error);
        }
    });
}

function avisos_descarga(id){
    window.location="../admin/avisos-descarga.php?id="+id; 
}

function avisos_edita(id){
    var par = '[{"id":"' + id + '"}]';
    $.ajax({
        url:        '../admin/avisos-edita.php',
        type:       'post',
        data:       parse_data(par), 
        dataType:   'json',
        cache:      false,
        success:    function (dt) {
            $('#txt_mes_edt').val(dt[0].avs_month);
            $('select[id=txt_nivel_edt]').val(dt[0].avs_level);
            $('#txt_filefake_edt').val(dt[0].avs_filename);
            $('#txt_id').val(dt[0].avs_id);

            
            $('#edita-circular').removeClass('hide');


            $('.btn_file_edt').on('click', function () {
                $('#txt_file_edt').trigger('click');
            })
            $('#txt_file_edt').on('change', function () {
                $('#txt_filefake_edt').removeClass('alerta');
                $(this).parent().parent().children('div.nota').html('');
                $('#txt_filefake_edt').val($(this).val());
            })
        
            $('.textbox').on('focus', function () {
                $(this).removeClass('alerta');
                $(this).parent().parent().children('div.nota').html('');
            });


            $('#formEdit').on('submit', function (e) {
                e.preventDefault();
                $('.loader').removeClass('oculto');
                
                    var f = $(this);
                    var formData = new FormData(document.getElementById('formEdit'));
                    formData.append('dato', 'valor');
                    $.ajax({
                        url: '../admin/avisos-actualiza.php',
                        type: 'post',
                        dataType: 'html',
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false,
                        success: function (dt) {
                            if (dt == 1) {
                                avisos_listado();
                                $('.textbox').val('');
                                $('.loader').addClass('oculto');
                                $('#edita-circular').addClass('hide');
                            } else {
                                console.log(dt);
                            }
                        },
                        error: function (xhr, textStatus, error) {
                            show_error(xhr, textStatus, error);
                        }
                    })
                
            });

        },
        error: function (xhr, textStatus, error) {
            show_error(xhr, textStatus, error);
        }
    });
}

function avisos_elimina(id){

    var conf= confirm("¿Realmente quieres eliminar este registro?")
    if (conf){
        var par = '[{"id":"' + id + '"}]';
        $.ajax({
            url:        '../admin/avisos-borra.php',
            type:       'post',
            data:       parse_data(par), 
            dataType:   'json',
            cache:      false,
            success:    function (dt) {
                if (dt[0].avs_id == 1) {
                    avisos_listado();
                    
                } else {
                    console.log(dt[0].avs_id);
                }
            },
            error: function (xhr, textStatus, error) {
                show_error(xhr, textStatus, error);
            }
        });
    }
}

function avisos_valida() {
    var v = 1;

    if ($('#txt_mes').val() == '') {
        v = 0;
        $('#nt_mes').html('Requerido');
        $('#txt_mes').addClass('alerta');
    }
    if ($('select[id=txt_nivel]').val() == '0') {
        v = 0;
        $('#nt_nivel').html('Requerido');
        $('#txt_nivel').addClass('alerta');
    }
    if ($('#txt_filefake').val() == '') {
        v = 0;
        $('#nt_file').html('Requerido');
        $('#txt_filefake').addClass('alerta');
    }

    return v;
}