$(document).ready(function () {

    $('.admmenu').on('click', function (e) {
        e.preventDefault()
        var opcion = $(this)
        pagina_select(opcion)
    });



});



function pagina_select(pg) {
    var pag = pg.attr('id') + '.php';

    $.ajax({
        url: '../admin/' + pag,
        type: 'post',
        cache: false,
        success: function (dt) {
            $('.content').html(dt)

            switch (pag){
                case 'avisos.php' : avisos_select(dt); break;
                default:
            }

        },
        error: function (xhr, textStatus, error) {
            show_error(xhr, textStatus, error);
        }
    });
}


