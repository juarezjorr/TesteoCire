<?php

include_once "../admin/lib/functions.php";

$sql = "SELECT avs_month, avs_level, avs_id, avs_filename 
        FROM avisos 
        ORDER BY avs_date DESC, avs_level";
        
$result = mysqli_query( $conn, $sql ) or die ('Algo en la consulta esta mal');

$i = 0;

while($row= mysqli_fetch_array($result)){
    $rowdata[$i] = $row;
    $i++;
}
if ($i > 0){
    echo json_encode($rowdata);
} else {
    echo '[{"avs_id":"0"}]';
}

mysqli_close($conn);

?>