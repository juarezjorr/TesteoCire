<?php

    include_once "../admin/lib/functions.php";

?>

<form  method="post" enctype="multipart/form-data" id="formfile">

    <div class="entrada">
        <h2>Agrega aviso</h2>

        <div class="grupo">
            <div class="etiqueta">Título</div>
            <div class="pregunta">
                <input type="text" name="txt_mes" id="txt_mes" class="textbox w100">
            </div>
            <div class="nota" id="nt_mes"></div>
        </div>
        <div class="grupo">
            <div class="etiqueta">Nivel</div>
            <div class="pregunta">
                <select name="txt_nivel" id="txt_nivel" class="textbox  w100">
                    <option value="0">Selecciona una secci&oacute;n</option>
                    <option value="BCA">Becas</option>
                    <option value="PRE">Preescolar</option>
                    <option value="PRI">Primaria</option>
                    <option value="SEC">Secundaria</option>
                </select>
            </div>
            <div class="nota" id="nt_nivel"></div>
        </div>

        <div class="grupo">
            <div class="etiqueta">Archivo</div>
            <div class="pregunta">
                <input type="file" name="txt_file" id="txt_file" class="oculto">
                <input type="text" name="txt_filefake" id="txt_filefake" readonly="true" class="textbox w80">
                <div class="btn_file">Examinar</div>
            </div>
            <div class="nota" id="nt_file"></div>
        </div>

        <div class="grupo">
            <div class="etiqueta">&nbsp;</div>
            <div class="pregunta">
                <input type="submit" value="Subir archivos" class="boton"/>
            </div>
            <div class="loader oculto" id="nt_uploader"><img src="../img/ajax-loader.gif"> Cargando aviso... </div>
        </div>

    </div>
</form>


<div class="listado">
    <div id="lst_pre" class="listas"><h3>BECAS      </h3><div class="lista" id="BCA"></div></div>    
    <div id="lst_pre" class="listas"><h3>PREESCOLAR </h3><div class="lista" id="PRE"></div></div>
    <div id="lst_pri" class="listas"><h3>PRIMARIA   </h3><div class="lista" id="PRI"></div></div>
    <div id="lst_sec" class="listas"><h3>SECUNDARIA </h3><div class="lista" id="SEC"></div></div>
</div>



<div id="edita-circular" class="modal hide">
    <form  method="post" enctype="multipart/form-data" id="formEdit">

    <div class="entrada">
        <h2>Edita aviso</h2>

        <div class="grupo">
            <div class="etiqueta">Título</div>
            <div class="pregunta">
                <input type="hidden" name="txt_id" id="txt_id">
                <input type="text" name="txt_mes_edt" id="txt_mes_edt" class="textbox w100">
            </div>
            <div class="nota" id="nt_mes_edt"></div>
        </div>
        <div class="grupo">
            <div class="etiqueta">Nivel</div>
            <div class="pregunta">
                <select name="txt_nivel_edt" id="txt_nivel_edt" class="textbox  w100">
                    <option value="0">Selecciona una secci&oacute;n</option>
                    <option value="BCA">Becas</option>
                    <option value="PRE">Preescolar</option>
                    <option value="PRI">Primaria</option>
                    <option value="SEC">Secundaria</option>
                </select>
            </div>
            <div class="nota" id="nt_nivel_edt"></div>
        </div>

        <div class="grupo">
            <div class="etiqueta">Archivo</div>
            <div class="pregunta">
                <input type="file" name="txt_file_edt" id="txt_file_edt" class="oculto">
                <input type="text" name="txt_filefake_edt" id="txt_filefake_edt" class="textbox w80" readonly="true">
                <div class="btn_file_edt">Examinar</div>
            </div>
            <div class="nota" id="nt_file_edt"></div>
        </div>

        <div class="grupo">
            <div class="etiqueta">&nbsp;</div>
            <div class="pregunta">
                <input type="submit" value="Aceptar cambios" class="boton"/>
            </div>
            <div class="loader oculto" id="nt_uploader"><img src="../img/ajax-loader.gif"> Cargando aviso... </div>
        </div>

    </div>
    </form>

</div>

<script src="<?php echo $host . "admin/js/avisos.js" ?>"></script>
