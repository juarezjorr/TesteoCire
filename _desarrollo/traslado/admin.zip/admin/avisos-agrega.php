<?php

if (isset($_POST['txt_mes'])){
    
    include_once "../admin/lib/functions.php";

    foreach ($_POST as $key => $value) {$_POST[$key]= mysqli_real_escape_string($conn, $value);}

    // get details of the uploaded file
    $fileTmpPath = $_FILES['txt_file']['tmp_name'];
    $fileName = $_FILES['txt_file']['name'];
    $fileSize = $_FILES['txt_file']['size'];
    $fileType = $_FILES['txt_file']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    $file = mysqli_real_escape_string($conn, file_get_contents( $_FILES['txt_file']['tmp_name']));
    $titulo = $_POST['txt_mes'];
    $nivel = $_POST['txt_nivel'];

    $newFileName = $fileName;

    $message = '';
    $allowedfileExtensions = array('pdf');
    if (in_array($fileExtension, $allowedfileExtensions)) {

        $sql = "INSERT INTO avisos (
              avs_filename
            , avs_filesize
            , avs_file
            , avs_contenttype
            , avs_month
            , avs_level
            , avs_date
        ) VALUES (
              '$newFileName'
            ,  $fileSize
            , '$file'
            , '$fileType'
            , '$titulo'
            , '$nivel'
            , now()
        )";

       

    /* NOTA cambiar el tamaño de max_allowed_packet=100M en my.ini */


    /* GUARDA ARCHIVO EN BASE DE DATOS MYSQL */        
        if ( mysqli_query($conn, $sql)){
            $message=1;
        } else {
            $message=mysqli_error($conn);
        }

    /* GUARDA ARCHIVO EN DIRECTORIO  */
        //     $uploadFileDir = '../circulares/';
        //     $dest_path = $uploadFileDir . $newFileName;
            
        //     if(move_uploaded_file($fileTmpPath, $dest_path))
        //     {
        //     $message ='1';
        //     }
        //     else
        //     {
        //     $message = 'Existe un error en la carga del archivo, asegurese de haber seleccionado el archivo correcto.';
        //     }
    

    } else {
        $message = 'El tipo de archivo debe ser PDF.';
    }

    echo $message;
    mysqli_close($conn);

}