<?php include_once "../admin/lib/functions.php"; ?>


<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>Liceo Albert Einstein</title>
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href=<?php echo $host . "admin/css/admin.css" ?>>
    <link rel="stylesheet" href=<?php echo $host . "admin/css/fonts.css" ?>>
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Titillium+Web' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
        integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

    <script src=<?php echo $host . "js/vendor/jquery-3.2.1.min.js" ?>></script>
    <script src=<?php echo $host . "js/lib/function.js" ?>></script>
    <script src=<?php echo $host . "admin/js/admin.js" ?>></script>
    
    


    <?php 
    
   
   
 ?>

</head>

<body>

    <div class="logo"></div>
    <div class="menu_bar">
        <a href="#" class="btn-menu"><span class="icon-file-text"></span>Menu</a>
    </div>
    <nav class="menu">
        <ul>
            <li><a href="#" id="avisos" class="admmenu">Avisos</a></li>
        </ul>
    </nav>

    <div class="content"></div>

</body>

</html>