<?php 

	// VARIABLES GLOBALES
	//$site = 'liceoalberteinstein/';
	$site = 'liceoalberteinstein.edu.mx/';

	$host = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $site;
	

	$conn = contecBD();
	
	// VARIABLES GLOBALES

	function contecBD(){

		// $server = 'localhost';
		// $user = 'extranet';
		// $passwd ='Jdk#7845%tY6';
		// $base = 'liceoae';

		$server = 'localhost';
		$user = 'root';
		$passwd ='';
		$base = 'liceoae';

		$connec = mysqli_connect( $server, $user, $passwd ) or die ('No se puede establecer la conexion');
		$db = mysqli_select_db( $connec, $base ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
		

		mysqli_set_charset($connec, "utf8");


		return $connec;
	}






	

?>