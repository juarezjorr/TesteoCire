<?php

    include_once "../admin/lib/functions.php";

    $avs_id = $_POST["id"];

    $sql = "SELECT avs_id, avs_month, avs_level, avs_filename
        FROM avisos 
        WHERE avs_id = {$avs_id}";

    $result = mysqli_query( $conn, $sql ) or die ('Algo en la consulta esta mal');
    $i = 0;

    while($row= mysqli_fetch_array($result)){
        $rowdata[$i] = $row;
        $i++;
    }
    if ($i > 0){
        echo json_encode($rowdata);
    } else {
        echo '[{"avs_id":"0"}]';
    }

    mysqli_close($conn);

?>