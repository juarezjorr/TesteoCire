<?php

    include_once "../admin/lib/functions.php";

    $avs_id = $_GET["id"];

    $sql = "SELECT avs_filename, avs_contenttype, avs_filesize, avs_file 
        FROM avisos 
        WHERE avs_id = {$avs_id}";

$result = mysqli_query( $conn, $sql ) or die ('Algo en la consulta esta mal' . mysqli_error($conn));


while($row = mysqli_fetch_assoc($result)) {
    $archivo = $row['avs_file'];
    $nombre = $row['avs_filename'];
    $tipo = $row['avs_contenttype'];
    $tamanio = $row['avs_filesize'];
 }

header("Cache-Control: public");
header("Content-Description: File Transfer");
header("Content-Transfer-Encoding: binary");
header("Content-Type: application/octet-stream");
header("Content-length: $tamanio");
header("Content-Disposition: inline; filename=$nombre");

echo $archivo;
