<?php

if (isset($_POST['id'])){

    include_once "../admin/lib/functions.php";

    $avs_id = $_POST['id'];

    $sql = "DELETE FROM avisos WHERE avs_id = {$avs_id}";

    $message='';
    if ( mysqli_query($conn, $sql)){
        $message='[{"avs_id":"1"}]';
    } else {
        $message='[{"avs_id":"'. mysqli_error($conn).'"}]';;
    }

    echo $message;
    mysqli_close($conn);

}