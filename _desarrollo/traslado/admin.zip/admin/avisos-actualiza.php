<?php

$message = '';
if (isset($_POST['txt_id'])){

    include_once "../admin/lib/functions.php";
    foreach ($_POST as $key => $value) {$_POST[$key]= mysqli_real_escape_string($conn, $value);}

    $id = $_POST['txt_id'];

    $sql = "UPDATE avisos SET
        avs_month = '{$_POST['txt_mes_edt']}'
      , avs_level = '{$_POST['txt_nivel_edt']}'
      , avs_date  = now()
    WHERE avs_id= {$id}";

    if ( mysqli_query($conn, $sql)){
        $message=1;
    } else {
        $message=mysqli_error($conn);
    }

    if( $_FILES['txt_file_edt']['tmp_name'] != ''){
        
        $fileTmpPath = $_FILES['txt_file_edt']['tmp_name'];
        $fileName = $_FILES['txt_file_edt']['name'];
        $fileSize = $_FILES['txt_file_edt']['size'];
        $fileType = $_FILES['txt_file_edt']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));
        $file = mysqli_real_escape_string($conn, file_get_contents( $_FILES['txt_file_edt']['tmp_name']));

        $newFileName = $fileName;

        $allowedfileExtensions = array('pdf');
        if (in_array($fileExtension, $allowedfileExtensions)) {

            $sql = "UPDATE avisos SET
                      avs_filename     =  '$newFileName'
                    , avs_filesize     =   $fileSize
                    , avs_file         =  '$file'
                    , avs_contenttype  =  '$fileType'
                    WHERE avs_id= {$id}";

        /* NOTA cambiar el tamaño de max_allowed_packet=100M en my.ini */


        /* GUARDA ARCHIVO EN BASE DE DATOS MYSQL */        
            if ( mysqli_query($conn, $sql)){
                $message=$message;
            } else {
                $message=mysqli_error($conn);
            }
        } 
    }
}

echo $message;
mysqli_close($conn);